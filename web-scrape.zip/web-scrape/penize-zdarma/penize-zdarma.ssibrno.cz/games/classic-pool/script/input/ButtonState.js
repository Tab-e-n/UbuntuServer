﻿"use strict";

function ButtonState() {
    this.down = false;
    this.pressed = false;
}